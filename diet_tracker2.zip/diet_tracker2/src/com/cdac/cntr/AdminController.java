package com.cdac.cntr;

import java.util.List;

import javax.servlet.http.HttpSession;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cdac.dto.Admin;
import com.cdac.dto.User;
import com.cdac.service.UserService;

@Controller
public class AdminController {
	@Autowired
	UserService userService;
	
	@RequestMapping(value = "/prep_ad_log_form.htm",method = RequestMethod.GET)
	public String prepLogForm(ModelMap map) {
		map.put("admin", new Admin());
		return "login_ad_form";
	}
	
	@RequestMapping(value = "/ad_login.htm",method = RequestMethod.POST)
	public String login(Admin admin,ModelMap map,HttpSession session) {
		
		if(admin.getAdminName().equals("admin") && admin.getAdminPass().equals("pass")) {
			admin.setAdminId(5);
			session.setAttribute("admin", admin);
			return "ad_home";
		}else {
			map.put("user", new Admin());
			return "login_ad_form";
		}
	}
	
	@RequestMapping(value = "/expense_list.htm",method = RequestMethod.GET)
	public String allExpenses(ModelMap map,HttpSession session) {
		
		List<User> li = userService.selectAll();
		map.put("expList", li);
	
		return "user_list";
	}
	
	@RequestMapping(value = "/logout.htm",method = RequestMethod.GET)
	public String prepLogForm(ModelMap map,HttpSession session) {
		session.removeAttribute("admin");
		session.invalidate();
		map.put("admin", new Admin());
		return "login_ad_form";
	}

}
