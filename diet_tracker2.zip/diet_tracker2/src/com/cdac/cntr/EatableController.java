package com.cdac.cntr;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cdac.dto.Eatables;
import com.cdac.dto.User;
import com.cdac.service.EatablesService;


@Controller
public class EatableController {
	@Autowired
	EatablesService eatablesService;
	@RequestMapping(value = "/prep_eat_form.htm",method = RequestMethod.GET)
	public String prepRegForm(ModelMap map) {
		map.put("eatables", new Eatables());
		return "reg_food";
	}
	
	@RequestMapping(value = "/reg_food.htm",method = RequestMethod.POST)
	public String register(Eatables eatables,ModelMap map) {
		eatablesService.addEatables(eatables);
		return "ad_home";
	}
	
	@RequestMapping(value = "/Eatable_list.htm",method = RequestMethod.GET)
	public String allExpenses(ModelMap map,HttpSession session) {
		//int userId = ((User)session.getAttribute("user")).getUserId();
		List<Eatables> li = eatablesService.selectAll();
		map.put("Eatables_List", li);
		return "eatables_list";
	}
	
	@RequestMapping(value = "/eat_delete.htm",method = RequestMethod.GET)
	public String expenseDelete(@RequestParam int eatId,ModelMap map,HttpSession session) {
		
		eatablesService.removeEatable(eatId); 
		
		//int userId = ((User)session.getAttribute("user")).getUserId();
		List<Eatables> li = eatablesService.selectAll();
		map.put("Eatables_List", li);
		return "eatables_list";
	}
	
	@RequestMapping(value = "/eat_update_form.htm",method = RequestMethod.GET)
	public String expenseUpdateForm(@RequestParam int eatId,ModelMap map) {
		
		Eatables eat = eatablesService.findEatable(eatId);
		map.put("eatables", eat);
		
		return "update_food";
	}
	
	@RequestMapping(value = "/eat_update.htm",method = RequestMethod.POST)
	public String expenseUpdate(Eatables eatables,ModelMap map,HttpSession session) {
		
		//int userId = ((User)session.getAttribute("user")).getUserId();
		//eatables.setUserId(userId);
		eatablesService.modifyExpense(eatables);
			
		List<Eatables> li = eatablesService.selectAll();
		map.put("Eatables_List", li);
		return "eatables_list";
	}
}
