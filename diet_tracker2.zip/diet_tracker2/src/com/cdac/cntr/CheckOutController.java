package com.cdac.cntr;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cdac.dto.CheckOut;
import com.cdac.dto.Eatables;
import com.cdac.dto.User;
import com.cdac.service.CheckOutService;
@Controller
public class CheckOutController {
	@Autowired
	CheckOutService checkOutService;
	
	@RequestMapping(value = "/new_check.htm",method = RequestMethod.GET)
	public String prepRegForm(ModelMap map) {
		map.put("checkOut", new CheckOut());
		return "add_check";
	}
	
	@RequestMapping(value = "/add_checkOut.htm",method = RequestMethod.POST)
	public String register(CheckOut checkOut,ModelMap map) {
		checkOutService.addCheckOut(checkOut);
		return "home";
	}
	
	@RequestMapping(value = "/getcheck.htm",method = RequestMethod.GET)
	public String allCheckOuts(ModelMap map,HttpSession session) {
		int userId = ((User)session.getAttribute("user")).getUserId();
		List<CheckOut> li = checkOutService.showCheckoutList(userId);
		map.put("checkOut_List", li);
		return "check_list";
	}
	
}
