package com.cdac.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
@Entity
public class Eatables {
	@Id
	@GeneratedValue
private int eatId;
private String eatType;
private int calories;
private String eatableName;
public Eatables() {
	super();
	// TODO Auto-generated constructor stub
}



public Eatables(int eatId) {
	this.eatId=eatId;
}



public String getEatableName() {
	return eatableName;
}



public void setEatableName(String eatableName) {
	this.eatableName = eatableName;
}



public int getEatId() {
	return eatId;
}
public void setEatId(int eatId) {
	this.eatId = eatId;
}
public String getEatType() {
	return eatType;
}
public void setEatType(String eatType) {
	this.eatType = eatType;
}
public int getCalories() {
	return calories;
}
public void setCalories(int calories) {
	this.calories = calories;
}


}
