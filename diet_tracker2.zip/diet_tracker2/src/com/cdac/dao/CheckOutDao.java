package com.cdac.dao;

import java.util.List;

import com.cdac.dto.CheckOut;

public interface CheckOutDao {
	void insertCheckOut(CheckOut checkOut);
	List<CheckOut> getCheckoutList(int userId);
	
	
}
