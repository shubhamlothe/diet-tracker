package com.cdac.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.cdac.dto.Eatables;
import com.cdac.dto.User;
@Repository
public class UserDaoImple implements UserDao {
	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	@Override
	public void insertUser(User user) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr=session.beginTransaction();
				int h=user.getHeight();
				int cw = user.getCurrWeight();
				int mh=h/100;
				float bmi = cw/(mh*mh);
				user.setBmi(bmi);
				if(user.getGender().equals("male")) {
					float bmr= (float) (66.47f + (13.75f * user.getCurrWeight()) + (5.003*user.getHeight())- (6.755*user.getAge()));
					user.setBmr(bmr);
					int cal= (int) (bmr*user.getActivity());
					user.setBudgetCal(cal);
				}
				else {
					float bmr= (float) (655.0955f + (9.5634f * user.getCurrWeight()) + (1.8496f *user.getHeight())- (4.6756f *user.getAge()));
					user.setBmr(bmr);
					int cal= (int) (bmr*user.getActivity());
					user.setBudgetCal(cal);
				}
				
				session.save(user);
				tr.commit();
				session.flush();
				session.close();
				return null;
				
			}
		});
		
	}
	
	@Override
	public boolean getuser(User user) {
		boolean b = hibernateTemplate.execute(new HibernateCallback<Boolean>() {

			@Override
			public Boolean doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from User where email = ? and password = ?");
				q.setString(0, user.getEmail());
				q.setString(1, user.getPassword());
				List<User> li = q.list();
				boolean flag = !li.isEmpty();
				tr.commit();
				session.flush();
				session.close();
				return flag;
			}
			
		});
		return b;
		
	}

	@Override
	public String forgotPassword(String email) {
		String password = hibernateTemplate.execute(new HibernateCallback<String>() {

			@Override
			public String doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from User where email = ?");
				q.setString(0, email);
				List<User> li = q.list();
				String pass = null;
				if(!li.isEmpty())
					pass = li.get(0).getPassword();
				tr.commit();
				session.flush();
				session.close();
				return pass;
			}
			
		});
		return password;
	}

	@Override
	public List<User> selectAll() {
		List<User> userList = hibernateTemplate.execute(new HibernateCallback<List<User>>() {

			@Override
			public List<User> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from User");
				
				List<User> li = q.list();
				System.out.println(li); 
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return userList;
		
	}

	@Override
	public User getUser(String email) {
		User user = hibernateTemplate.execute(new HibernateCallback<User>() {

			@Override
			public User doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from User where email = ?");
				q.setString(0, email);
				List<User> li = q.list();
				User pass = null;
				if(!li.isEmpty())
					pass = li.get(0);
				tr.commit();
				session.flush();
				session.close();
				return pass;
			}
			
		});
		return user;
	}

	@Override
	public void updateUser(User user) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				User us = (User)session.get(User.class, user.getUserId());
				System.out.println(user);
				System.out.println("===========");
				System.out.println(us);
				us.setActivity(user.getActivity());
				us.setAge(user.getAge());
				us.setBmi(user.getBmi());
				us.setBmr(user.getBmr());
				us.setBudgetCal(user.getBudgetCal());
				us.setCurrWeight(user.getCurrWeight());
				us.setDateOfBirth(user.getDateOfBirth());
				us.setEmail(user.getEmail());
				us.setFirstName(user.getFirstName());
				us.setGender(user.getGender());
				us.setGoalWeight(user.getGoalWeight());
				us.setHeight(user.getCurrWeight());
				us.setLastName(user.getLastName());
				us.setPassword(user.getPassword());
				us.setUserId(user.getUserId());
				
				int h=user.getHeight();
				int cw = user.getCurrWeight();
				int mh=h/100;
				float bmi = cw/(mh*mh);
				us.setBmi(bmi);
				if(user.getGender().equals("male")) {
					float bmr= (float) (66.47f + (13.75f * user.getCurrWeight()) + (5.003*user.getHeight())- (6.755*user.getAge()));
					us.setBmr(bmr);
					int cal= (int) (bmr*user.getActivity());
					us.setBudgetCal(cal);
				}
				else {
					float bmr= (float) (655.0955f + (9.5634f * user.getCurrWeight()) + (1.8496f *user.getHeight())- (4.6756f *user.getAge()));
					user.setBmr(bmr);
					int cal= (int) (bmr*user.getActivity());
					us.setBudgetCal(cal);
				}
				
				session.update(us);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}

}
