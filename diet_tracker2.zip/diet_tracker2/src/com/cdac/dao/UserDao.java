package com.cdac.dao;

import java.util.List;

import com.cdac.dto.User;

public interface UserDao {
	void insertUser(User user);
	boolean getuser(User user);
	String forgotPassword(String email);
	List<User> selectAll();
	User getUser(String email);
	void updateUser(User user);
}
