package com.cdac.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.cdac.dto.Eatables;
@Repository
public class EatablesDoaImple  implements EatableDao{

	@Autowired
	private HibernateTemplate hibernateTemplate;
	@Override
	public void insertEatables(Eatables eatables) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr=session.beginTransaction();
				
				
				session.save(eatables);
				tr.commit();
				session.flush();
				session.close();
				return null;
				
			}
		});
		
		
	}
	@Override
	public List<Eatables> getall() {
		List<Eatables> Eatables_List = hibernateTemplate.execute(new HibernateCallback<List<Eatables>>() {

			@Override
			public List<Eatables> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Eatables");
				
				List<Eatables> li = q.list();
				System.out.println(li); 
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return Eatables_List;
	}
	@Override
	public void deleteEatable(int eatId) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.delete(new Eatables(eatId));
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}
	@Override
	public void updateEatable(Eatables eatables) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Eatables ex = (Eatables)session.get(Eatables.class, eatables.getEatId());
				ex.setCalories(eatables.getCalories());
				ex.setEatableName(eatables.getEatableName());
				ex.setEatId(eatables.getEatId());
				ex.setEatType(eatables.getEatType());
				session.update(ex);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}
	@Override
	public Eatables selectEatable(int eatId) {
		Eatables eatable = hibernateTemplate.execute(new HibernateCallback<Eatables>() {

			@Override
			public Eatables doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Eatables ex = (Eatables)session.get(Eatables.class, eatId);
				tr.commit();
				session.flush();
				session.close();
				return ex;
			}
			
		});
		return eatable;
	}
	

}
