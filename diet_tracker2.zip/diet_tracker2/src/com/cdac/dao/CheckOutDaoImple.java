package com.cdac.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.cdac.dto.CheckOut;
import com.cdac.dto.Eatables;
@Repository
public class CheckOutDaoImple implements CheckOutDao{
	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	@Override
	public void insertCheckOut(CheckOut checkOut) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr=session.beginTransaction();
				
				
				session.save(checkOut);
				tr.commit();
				session.flush();
				session.close();
				return null;
				
			}
		});
		
	}

	@Override
	public List<CheckOut> getCheckoutList(int userId) {
		List<CheckOut> CheckOut_List = hibernateTemplate.execute(new HibernateCallback<List<CheckOut>>() {

			@Override
			public List<CheckOut> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from CheckOut where userId =?");
				q.setInteger(0, userId);
				List<CheckOut> li = q.list();
				
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return CheckOut_List;
	}

}
