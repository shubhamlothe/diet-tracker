package com.cdac.dao;

import java.util.List;

import com.cdac.dto.Eatables;

public interface EatableDao {
	void insertEatables(Eatables eatables);

	List<Eatables> getall();

	void deleteEatable(int eatId);

	void updateEatable(Eatables eatables);

	Eatables selectEatable(int eatId);
}
