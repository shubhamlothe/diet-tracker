package com.cdac.service;

import java.util.List;

import com.cdac.dto.CheckOut;

public interface CheckOutService {
	void addCheckOut(CheckOut checkOut);
	List<CheckOut> showCheckoutList(int userId);
}
