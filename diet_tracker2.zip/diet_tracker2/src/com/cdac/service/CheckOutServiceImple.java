package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dto.CheckOut;
import com.cdac.dao.CheckOutDao;
@Service
public class CheckOutServiceImple implements CheckOutService{

	@Autowired
	CheckOutDao checkOutDao;
	
	@Override
	public void addCheckOut(CheckOut checkOut) {
		checkOutDao.insertCheckOut(checkOut);
		
	}

	@Override
	public List<CheckOut> showCheckoutList(int userId) {
		
		return checkOutDao.getCheckoutList(userId);
	}

}
