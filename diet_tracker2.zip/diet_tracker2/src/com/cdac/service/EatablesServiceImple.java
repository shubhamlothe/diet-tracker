package com.cdac.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.EatableDao;
import com.cdac.dto.Eatables;
@Service
public class EatablesServiceImple implements EatablesService{
	@Autowired
	EatableDao eatabledao;
	
		
	


	@Override
	public void addEatables(Eatables eatables) {
		eatabledao.insertEatables(eatables);
		
	}





	@Override
	public List<Eatables> selectAll() {
		
		return eatabledao.getall();
	}





	@Override
	public void removeEatable(int eatId) {
		eatabledao.deleteEatable(eatId);
		
	}





	@Override
	public void modifyExpense(Eatables eatables) {
		eatabledao.updateEatable(eatables);
		
	}





	@Override
	public Eatables findEatable(int eatId) {
		
		return eatabledao.selectEatable(eatId);
	}

}
