package com.cdac.service;

import java.util.List;

import com.cdac.dto.Eatables;

public interface EatablesService {
	void addEatables(Eatables eatables);

	List<Eatables> selectAll();

	void removeEatable(int eatId);

	void modifyExpense(Eatables eatables);

	Eatables findEatable(int eatId);
	
}
