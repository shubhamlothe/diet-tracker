package com.cdac.service;



import java.util.List;

import com.cdac.dto.User;

public interface UserService {
	void addUser(User user);
	boolean findUser(User user);
	String forgotPassword(String email);
	List<User> selectAll();
	User findUser(String email);
	void modifyUser(User user);
	
	

}
